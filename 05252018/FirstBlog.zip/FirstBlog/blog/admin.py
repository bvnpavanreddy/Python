from django.contrib import admin
from blog.models import posts

admin.site.register(posts)